﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player_Management : MonoBehaviour
{
    public Slider waterSlider;
    public Slider sunlightSlider;
    public Slider oxygenSlider;
    public Slider Lifeslider;

    public GameObject fireballPrefab; // Fireball Prefab
    public Transform firePoint; // The point from where the fireball will be fired
    public float fireballSpeed = 20f; // Speed at which the fireball moves
    public AudioClip fireSound; // 🔥 Fireball sound to play on pressing "J"

    public float depletionRatemovsun = 0.5f;
    public float depletionRatemovwater = 0.75f;
    public float depletionRatemovox = 0.5f;
    public float depletionrateidlesun = 0.3f;
    public float depletionrateidlewater = 0.3f;
    public float depletionrateidleox = 0.2f;
    public float minValue = 0f;

    private CharacterController controller;
    private Vector3 lastPosition;
    private bool isIdle;


    void Start()
    {
        controller = GetComponent<CharacterController>();
        lastPosition = transform.position;
        SetInitialValues();
    }

    void Update()
    {
        DetectMovement();

        if (isIdle == true)
        {
            DecreaseStatsOverTime();
        }
        if (isIdle == false)
        {
            DecreaseStatsOverTimeidle();
        }

        // Fire the fireball when "J" is pressed
        if (Input.GetKeyDown(KeyCode.F))
        {
            FireFireball();
        }
    }

    void SetInitialValues()
    {
        float initialValuesun = 45f;
        float initialValuewater = 50f;
        float initialValueox = 55f;
        float initialValueLife = 100f;

        if (waterSlider != null) waterSlider.value = initialValuewater;
        if (sunlightSlider != null) sunlightSlider.value = initialValuesun;
        if (oxygenSlider != null) oxygenSlider.value = initialValueox;
        if (Lifeslider != null) Lifeslider.value = initialValueLife;
    }

    void DetectMovement()
    {
        if (Vector3.Distance(transform.position, lastPosition) < 0.01f)
        {
            isIdle = true;
        }
        else
        {
            isIdle = false;
        }

        lastPosition = transform.position;
    }

    void DecreaseStatsOverTime()
    {
        float deltasun = depletionRatemovsun * Time.deltaTime;
        float deltawater = depletionRatemovwater * Time.deltaTime;
        float deltaox = depletionRatemovox * Time.deltaTime;

        if (waterSlider != null && waterSlider.value > minValue && waterSlider.value < 100f)
        {
            waterSlider.value -= deltawater;
            if (waterSlider.value <= 0)
            {
                SceneManager.LoadScene("lose");
            }
        }

        if (sunlightSlider != null && sunlightSlider.value > minValue && sunlightSlider.value < 100f)
        {
            sunlightSlider.value -= deltasun;
            if (sunlightSlider.value <= 0)
            {
                SceneManager.LoadScene("lose");
            }
        }

        if (oxygenSlider != null && oxygenSlider.value > minValue && oxygenSlider.value < 100f)
        {
            oxygenSlider.value -= deltaox;
            if (oxygenSlider.value <= 0)
            {
                SceneManager.LoadScene("lose");
            }
        }
    }


    void DecreaseStatsOverTimeidle()
    {
        float deltasun = depletionrateidlesun * Time.deltaTime;
        float deltawater = depletionrateidlewater * Time.deltaTime;
        float deltaox = depletionrateidleox * Time.deltaTime;

        if (waterSlider != null && waterSlider.value > minValue && waterSlider.value < 100f)
        {
            waterSlider.value -= deltawater;
            if (waterSlider.value <= 0)
            {
                SceneManager.LoadScene("lose");
            }
        }

        if (sunlightSlider != null && sunlightSlider.value > minValue && sunlightSlider.value < 100f)
        {
            sunlightSlider.value -= deltasun;
            if (sunlightSlider.value <= 0)
            {
                SceneManager.LoadScene("lose");
            }
        }

        if (oxygenSlider != null && oxygenSlider.value > minValue && oxygenSlider.value < 100f)
        {
            oxygenSlider.value -= deltaox;
            if (oxygenSlider.value <= 0)
            {
                SceneManager.LoadScene("lose");
            }
        }
    }


    public void ReduceLife(float amount)
    {
        if (Lifeslider != null)
        {
            Lifeslider.value -= amount;
            if (Lifeslider.value <= 0)
            {
                SceneManager.LoadScene("lose");
            }
        }
    }


    // Fire the fireball when "J" is pressed
    void FireFireball()
    {
        if (fireballPrefab != null && firePoint != null)
        {
            GameObject fireball = Instantiate(fireballPrefab, firePoint.position, firePoint.rotation);
            Rigidbody rb = fireball.GetComponent<Rigidbody>();

            if (rb != null)
            {
                rb.velocity = firePoint.forward * fireballSpeed;
            }

            // 🔊 Play fire sound at firePoint position
            if (fireSound != null)
            {
                GameObject tempAudioObj = new GameObject("FireSound");
                tempAudioObj.transform.position = firePoint.position;

                AudioSource audioSource = tempAudioObj.AddComponent<AudioSource>();
                audioSource.clip = fireSound;
                audioSource.spatialBlend = 1f; // 3D sound
                audioSource.Play();

                Destroy(tempAudioObj, fireSound.length); // Auto-destroy after playback
            }
        }
    }

    public void IncreaseStats(float amount, string statType)
    {
        switch (statType)
        {
            case "Water":
                if (waterSlider != null)
                {
                    waterSlider.value = Mathf.Min(waterSlider.maxValue, waterSlider.value + amount);
                }
                break;

            case "Sun":
                if (sunlightSlider != null)
                {
                    sunlightSlider.value = Mathf.Min(sunlightSlider.maxValue, sunlightSlider.value + amount);
                }
                break;

            case "Oxygen":
                if (oxygenSlider != null)
                {
                    oxygenSlider.value = Mathf.Min(oxygenSlider.maxValue, oxygenSlider.value + amount);
                }
                break;
        }
    }


}
