﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerfire : MonoBehaviour
{
    public float speed = 10f;  // Speed at which the fire moves
    private Rigidbody rb;

    public GameObject[] collectiblePrefabs; // Array to store Water, Sun, and Oxygen prefabs
    public AudioClip hitEnemySound;         // 🎵 Assign this in the Inspector

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        Destroy(gameObject, 5f); // Destroy after 5 seconds
    }

    void FixedUpdate()
    {
        // Move in the direction the fire is currently facing
        rb.MovePosition(rb.position + transform.forward * speed * Time.fixedDeltaTime);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("enemy"))
        {
            // Play sound at the hit point
            if (hitEnemySound != null)
                AudioSource.PlayClipAtPoint(hitEnemySound, collision.transform.position);

            // Destroy the enemy object
            Destroy(collision.gameObject);

            // Instantiate a random collectible at the enemy's position
            if (collectiblePrefabs.Length > 0)
            {
                int randomIndex = Random.Range(0, collectiblePrefabs.Length);
                Vector3 spawnPosition = collision.transform.position + Vector3.up * 0.6f;
                Instantiate(collectiblePrefabs[randomIndex], spawnPosition, Quaternion.identity);
            }

            // Destroy the fireball
            Destroy(gameObject);
        }
    }
}
