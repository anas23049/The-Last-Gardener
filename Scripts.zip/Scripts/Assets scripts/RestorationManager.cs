﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class RestorationManager : MonoBehaviour
{
    public Text alienMessageText;
    public GameObject platform;
    public static RestorationManager Instance;

    public int totalBuildings = 0;
    public int restoredBuildings = 0;

    public Slider globalRestorationSlider;
    public Slider waterSlider;
    public Slider oxygenSlider;
    public Slider sunlightSlider;

    public Camera mainCamera;
    public Material finalSkybox;

    public GameObject plant1;
    public GameObject plant2;
    public GameObject plant3;
    public GameObject plant4;
    public GameObject plant5;
    public GameObject plant6;

    public GameObject plant11;
    public GameObject plant22;
    public GameObject plant33;
    public GameObject plant44;

    public BoxCollider explorationGateCollider;

    private bool winConditionTriggered = false;
    private bool colliderDeactivated = false;

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    private void Start()
    {
        if (globalRestorationSlider != null)
        {
            globalRestorationSlider.maxValue = 13f;
            globalRestorationSlider.value = 0f;
        }

        if (explorationGateCollider != null)
            explorationGateCollider.enabled = true;

        platform.SetActive(false);
        UpdateSlider();
    }

    private void Update()
    {
        CheckColliderCondition();
    }

    public void RegisterBuilding()
    {
        totalBuildings++;
        UpdateSlider();
    }

    public void BuildingRestored()
    {
        restoredBuildings++;
        UpdateSlider();
        MovePlantOnRestoration(restoredBuildings);
    }

    public int GetRestoredCount()
    {
        return restoredBuildings;
    }

    void MovePlantOnRestoration(int count)
    {
        switch (count)
        {
            case 1: if (plant1 != null) plant1.transform.position += new Vector3(0, 12f, 0); break;
            case 2: if (plant2 != null) plant2.transform.position += new Vector3(0, 9f, 0); break;
            case 3: if (plant3 != null) plant3.transform.position += new Vector3(0, 8f, 0); break;
            case 4: if (plant4 != null) plant4.transform.position += new Vector3(0, 25f, 0); break;
            case 5: if (plant5 != null) plant5.transform.position += new Vector3(0, 7f, 0); break;
            case 6: if (plant6 != null) plant6.transform.position += new Vector3(0, 8f, 0); break;
        }
    }

    void CheckColliderCondition()
    {
        if (!colliderDeactivated &&
            globalRestorationSlider != null &&
            globalRestorationSlider.value >= globalRestorationSlider.maxValue)
        {
            colliderDeactivated = true;

            if (explorationGateCollider != null)
                explorationGateCollider.enabled = false;

            if (platform != null)
                platform.SetActive(true);

            ApplyFinalSkybox();
        }
    }

    IEnumerator ShowAlienMessageThenActivatePlatform()
    {
        alienMessageText.gameObject.SetActive(true);
        alienMessageText.text = "The city is now fully restored and recovered, and the aliens have vanished. Your next mission is to take control of the city and destroy the alien cyber machine. Go and find it.";

        yield return new WaitForSeconds(5f);

        alienMessageText.gameObject.SetActive(false);
        platform.SetActive(true);
    }

    void ApplyFinalSkybox()
    {
        if (mainCamera != null)
            mainCamera.enabled = true;

        if (finalSkybox != null)
        {
            RenderSettings.skybox = finalSkybox;
            DynamicGI.UpdateEnvironment();

            // Activate all plants
            plant11?.SetActive(true);
            plant22?.SetActive(true);
            plant33?.SetActive(true);
            plant44?.SetActive(true);

            // Destroy aliens
            GameObject[] aliens = GameObject.FindGameObjectsWithTag("enemy");
            foreach (GameObject alien in aliens)
                Destroy(alien);

            // Destroy enemy fire
            GameObject[] enemyFires = GameObject.FindGameObjectsWithTag("fire");
            foreach (GameObject fire in enemyFires)
                Destroy(fire);

            // Show message
            if (alienMessageText != null)
                StartCoroutine(ShowAlienMessageThenActivatePlatform());
        }
    }


    void UpdateSlider()
    {
        if (globalRestorationSlider != null)
            globalRestorationSlider.value = restoredBuildings;
    }
}
