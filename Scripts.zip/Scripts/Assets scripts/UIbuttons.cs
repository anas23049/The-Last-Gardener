using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UIbuttons : MonoBehaviour
{
    [SerializeField] GameObject buttons;
    [SerializeField] GameObject banner;
    [SerializeField] GameObject about;
    [SerializeField] AudioClip clickSound;

    private AudioSource audioSource;
    private bool isMenuActive = false;

    void Start()
    {
        // Add or get an AudioSource component
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    private void PlayClickSound()
    {
        if (clickSound != null)
        {
            audioSource.PlayOneShot(clickSound);
        }
    }

    public void ToggleMenu()
    {
        PlayClickSound();
        if (isMenuActive)
        {
            buttons.SetActive(false);
            Time.timeScale = 1; // Resume game time
            isMenuActive = false;
        }
        else
        {
            buttons.SetActive(true);
            Time.timeScale = 1; // Pause game time
            isMenuActive = true;
        }
    }

    public void About()
    {
        PlayClickSound();
        if (about.activeSelf)
        {
            about.SetActive(false);  // Hide the about banner if it's already open
            Time.timeScale = 1; // Resume game time
        }
        else
        {
            about.SetActive(true);  // Show the about banner
            Time.timeScale = 0; // Pause game time
        }
    }

    //public void cross()
    //{
    //    PlayClickSound();
    //    About.SetActive(false);
    //    Time.timeScale = 1;
    //}

    public void restart()
    {
        AudioListener.pause = false;
        PlayClickSound();
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        Time.timeScale = 1;
    }

  
    public void mainmenuscene()
    {
 
        PlayClickSound();
        SceneManager.LoadScene("mainmenu");
        Time.timeScale = 1;
    }

    public void quitt()
    {
        PlayClickSound();
        Application.Quit();
    }



    public void pause()
    {
        AudioListener.pause = true; 
        PlayClickSound();
        Time.timeScale = 0;
        banner.SetActive(true);

    }



    public void resume()
    {
        AudioListener.pause = false;
        PlayClickSound();
        Time.timeScale = 1;
        banner.SetActive(false);
    }
    public void scenechangetointro()
    {
        PlayClickSound();
        SceneManager.LoadScene("intro");
        Time.timeScale = 1;

    }
        

}
