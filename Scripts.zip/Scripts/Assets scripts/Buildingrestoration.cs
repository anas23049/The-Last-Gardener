﻿using UnityEngine;
using UnityEngine.UI;

public class Buildingrestoration : MonoBehaviour
{
    public Slider restorationSlider;
    public GameObject destroyedBuilding;
    public GameObject restoredBuilding;
    public float restorationSpeed = 100f;

    public AudioClip restorationCompleteSound; // One-shot sound
    public AudioClip restorationLoopSound;     // Looping sound during restoration

    private bool isPlayerInside = false;
    private GameObject loopAudioObject;        // Temporary GameObject for looping sound
    private AudioSource loopSource;

    void Start()
    {
        if (restorationSlider != null)
        {
            restorationSlider.gameObject.SetActive(false);
            restorationSlider.value = 0f;
        }

        if (restoredBuilding != null)
            restoredBuilding.SetActive(false);

        if (RestorationManager.Instance != null)
            RestorationManager.Instance.RegisterBuilding();
    }

    void Update()
    {
        if (isPlayerInside && restorationSlider != null && restorationSlider.value < restorationSlider.maxValue)
        {
            restorationSlider.value += restorationSpeed * Time.deltaTime;

            if (loopSource == null && restorationLoopSound != null)
            {
                // Create audio source and play loop
                loopAudioObject = new GameObject("RestorationLoopSound");
                loopSource = loopAudioObject.AddComponent<AudioSource>();
                loopSource.clip = restorationLoopSound;
                loopSource.loop = true;
                loopSource.spatialBlend = 1f; // 3D sound
                loopSource.transform.position = transform.position;
                loopSource.Play();
            }

            if (restorationSlider.value >= restorationSlider.maxValue)
            {
                CompleteRestoration();
            }
        }
        else
        {
            StopLoopingSound();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInside = true;
            if (restorationSlider != null)
                restorationSlider.gameObject.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInside = false;
            if (restorationSlider != null)
                restorationSlider.gameObject.SetActive(false);

            StopLoopingSound();
        }
    }

    void CompleteRestoration()
    {
        if (restoredBuilding != null)
            restoredBuilding.SetActive(true);

        if (destroyedBuilding != null)
            destroyedBuilding.SetActive(false);

        if (restorationSlider != null)
        {
            restorationSlider.value = 0f;
            restorationSlider.gameObject.SetActive(false);
        }

        StopLoopingSound();

        if (restorationCompleteSound != null)
            AudioSource.PlayClipAtPoint(restorationCompleteSound, transform.position);

        if (RestorationManager.Instance != null)
            RestorationManager.Instance.BuildingRestored();
    }

    void StopLoopingSound()
    {
        if (loopSource != null)
        {
            loopSource.Stop();
            Destroy(loopAudioObject);
            loopSource = null;
            loopAudioObject = null;
        }
    }
}
