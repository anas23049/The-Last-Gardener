using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum CollectibleType
{
    Water,
    Sun,
    Oxygen
}

public class collectiblesmovement : MonoBehaviour
{
    public CollectibleType collectibleType;
    public float floatAmplitude = 0.5f;
    public float floatFrequency = 1f;

    public AudioClip collectSound; // ?? Assign this from Inspector

    private Vector3 startPosition;

    void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {
        float newY = startPosition.y + Mathf.Sin(Time.time * floatFrequency) * floatAmplitude;
        transform.position = new Vector3(startPosition.x, newY, startPosition.z);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Player_Management pm = other.GetComponent<Player_Management>();
            if (pm != null)
            {
                // Increase the specific stat based on the collectible type
                switch (collectibleType)
                {
                    case CollectibleType.Water:
                        pm.IncreaseStats(5f, "Water");
                        break;
                    case CollectibleType.Sun:
                        pm.IncreaseStats(5f, "Sun");
                        break;
                    case CollectibleType.Oxygen:
                        pm.IncreaseStats(5f, "Oxygen");
                        break;
                }
            }

            // ?? Play sound if assigned
            if (collectSound != null)
                AudioSource.PlayClipAtPoint(collectSound, transform.position);

            Destroy(gameObject); // Remove the collectible after being picked
        }
    }
}
