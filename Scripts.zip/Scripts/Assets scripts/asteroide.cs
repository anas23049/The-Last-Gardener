﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class asteroide : MonoBehaviour
{
    public Transform target;
    public float speed = 5f;
    public GameObject firePrefab;
    public float fireScaleFactor = 10f;

    public Image whiteFlash;
    public Text messageText;
    public GameObject image;

    public AudioClip typeSound;
    public AudioClip asteroidComingSound;
    public AudioClip asteroidHitSound;

    private AudioSource audioSource;
    private AudioSource loopingSource;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        // Typing & one-shot sounds
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false;

        // Looping asteroid sound
        loopingSource = gameObject.AddComponent<AudioSource>();
        loopingSource.clip = asteroidComingSound;
        loopingSource.loop = true;
        loopingSource.playOnAwake = false;
        loopingSource.Play();

        // Instantiate fire
        Vector3 fireOffset = -transform.forward * 0f;
        GameObject fireObj = Instantiate(firePrefab, transform.position + fireOffset, Quaternion.identity);
        fireObj.transform.SetParent(transform);
        fireObj.transform.rotation = Quaternion.LookRotation(-transform.forward, transform.up);
        fireObj.transform.localScale = transform.localScale * fireScaleFactor;

        ParticleSystem fire = fireObj.GetComponent<ParticleSystem>();
        if (fire != null) fire.Play();

        // Transparent white flash at start
        if (whiteFlash != null)
            whiteFlash.color = new Color(1, 1, 1, 0);

        // Hide message initially
        if (messageText != null)
            messageText.gameObject.SetActive(false);
    }

    void FixedUpdate()
    {
        if (target != null)
        {
            Vector3 direction = (target.position - transform.position).normalized;

            if (direction != Vector3.zero)
            {
                Quaternion lookRotation = Quaternion.LookRotation(direction);
                rb.MoveRotation(Quaternion.Slerp(rb.rotation, lookRotation, Time.fixedDeltaTime * 5f));
            }

            Vector3 newPosition = rb.position + direction * speed * Time.fixedDeltaTime;
            rb.MovePosition(newPosition);
        }
    }

    IEnumerator TypeWriterEffect(string fullText, float delay)
    {
        messageText.text = "";
        image.gameObject.SetActive(true);
        messageText.gameObject.SetActive(true);

        audioSource.PlayOneShot(typeSound);

        for (int i = 0; i < fullText.Length; i++)
        {
            messageText.text += fullText[i];
            yield return new WaitForSeconds(delay);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("target"))
        {
            if (whiteFlash != null)
                whiteFlash.color = new Color(1, 1, 1, 1);

            GetComponent<Collider>().enabled = false;
            GetComponent<MeshRenderer>().enabled = false;
            rb.isKinematic = true;

            // 🔇 Stop asteroid flying sound
            if (loopingSource.isPlaying)
                loopingSource.Stop();

            // 💥 Play asteroid hit sound
            if (asteroidHitSound != null)
                audioSource.PlayOneShot(asteroidHitSound);

            StartCoroutine(LoadSceneAfterDelay());
        }
    }

    IEnumerator LoadSceneAfterDelay()
    {
        yield return new WaitForSeconds(2f);

        if (messageText != null)
        {
            string finalMessage = "THE ANCIENT CITY HAS FALLEN.\r\nOnce a thriving land of history and mystery — now reduced to ruins.\r\nYou are the last survivor.\r\n\r\nThe city has transformed into a cybernetic realm, pulsing with unknown energy and scattered with strange powers.\r\n\r\nAdapt. Survive. Evolve.";
            StartCoroutine(TypeWriterEffect(finalMessage, 0.041f));
        }

        yield return new WaitForSeconds(20f);
        SceneManager.LoadScene("main");
    }
}
