using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraswicthing : MonoBehaviour
{
    public CinemachineVirtualCamera vCam1;
    public CinemachineVirtualCamera vCam2;
    public CinemachineVirtualCamera vCam3;
    public CinemachineVirtualCamera vCam4;
    public CinemachineVirtualCamera vCam5;
    public CinemachineVirtualCamera vCam6;


    void Start()
    {
        StartCoroutine(PlayCinematic());
    }

    IEnumerator PlayCinematic()
    {
        EnableOnly(vCam1);
        yield return new WaitForSeconds(4f);

        EnableOnly(vCam2);
        yield return new WaitForSeconds(2f);

        EnableOnly(vCam3);
        yield return new WaitForSeconds(3f);

        EnableOnly(vCam4);
        yield return new WaitForSeconds(4f);

        EnableOnly(vCam5);
        yield return new WaitForSeconds(4f);
        EnableOnly(vCam6);
        yield return new WaitForSeconds(5f);

        // Optional: Disable all vCams or enable player cam here
    }

    void EnableOnly(CinemachineVirtualCamera activeCam)
    {
        vCam1.gameObject.SetActive(false);
        vCam2.gameObject.SetActive(false);
        vCam3.gameObject.SetActive(false);
        vCam4.gameObject.SetActive(false);
        vCam5.gameObject.SetActive(false);
        vCam6.gameObject.SetActive(false);

        activeCam.gameObject.SetActive(true);
    }
}
