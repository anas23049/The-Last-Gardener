using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlienSpawn : MonoBehaviour
{
    public GameObject alienPrefab;       // Alien prefab to spawn
    public GameObject centerObject;      // Reference to the center GameObject
    public int numberOfAliens = 100;     // Total aliens to spawn
    public float spawnRadius = 400f;     // Radius from center to spawn within

    void Start()
    {
        SpawnAliens();
    }

    void SpawnAliens()
    {
        if (alienPrefab == null || centerObject == null)
        {
            Debug.LogWarning("Alien prefab or center object not assigned!");
            return;
        }

        for (int i = 0; i < numberOfAliens; i++)
        {
            Vector3 randomPos = Random.insideUnitSphere * spawnRadius;
            randomPos.y = 0; // Optional: keep all aliens on the ground

            Vector3 spawnPosition = centerObject.transform.position + randomPos;

            Instantiate(alienPrefab, spawnPosition, Quaternion.identity);
        }
    }
}
