using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class HackingMachine : MonoBehaviour
{
    public GameObject hackingObject;
    public Slider hackingSlider;
    public Text progressText; // Text component to display the progress
    public float hackingSpeed = 30f;
    public AudioClip hackingSound;
    private AudioSource audioSource;

    private bool isPlayerHacking = false;
    private bool hasHacked = false; // Prevent multiple scene loads
    private float hackingProgress = 0f; // New variable to track hacking progress

    void Start()
    {
        if (hackingSlider != null)
        {
            hackingSlider.value = -100f;
            hackingSlider.gameObject.SetActive(false);
        }

        audioSource = GetComponent<AudioSource>();
        if (audioSource != null && hackingSound != null)
        {
            audioSource.clip = hackingSound;
        }

        // Initialize progress text
        if (progressText != null)
        {
            progressText.text = "Hacking: 0%"; // Show initial progress
        }
    }

    void Update()
    {
        // If progress reaches or exceeds 100, switch to win scene
        if (hackingSlider.value >= 100f)
        {
            SceneManager.LoadScene("win"); // Switch to the win scene
        }
        if (isPlayerHacking && hackingSlider != null && !hasHacked)
        {
            // Increment the hacking progress
            hackingProgress += hackingSpeed * Time.deltaTime;

            // Update the slider to match the progress (visual representation)
            hackingSlider.value = hackingProgress;

            // Update the text to show current progress
            if (progressText != null)
            {
                progressText.text = "Hacking: " + Mathf.FloorToInt(hackingProgress) + "%";
            }

            // Start playing the sound if it isn't already
            if (!audioSource.isPlaying && audioSource != null)
            {
                audioSource.Play();
            }

            
        }
        else if (!isPlayerHacking && audioSource.isPlaying)
        {
            audioSource.Stop();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player started hacking.");
            isPlayerHacking = true;
            if (hackingSlider != null)
                hackingSlider.gameObject.SetActive(true);

            // Immediately load the win scene when hacking begins
            if (hackingSlider.value>95f)
            {
                hasHacked = true;
                SceneManager.LoadScene("win"); // Switch to the win scene
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player stopped hacking.");
            isPlayerHacking = false;
            if (hackingSlider != null)
                hackingSlider.gameObject.SetActive(false);
        }
    }

    private IEnumerator LoadWinSceneAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        SceneManager.LoadScene("win");
    }
}
