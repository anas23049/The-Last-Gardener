using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CameraSwitchingForWin : MonoBehaviour
{
    public List<Camera> cameras = new List<Camera>(); // Drag cameras in Inspector
    public float switchDelay = 3f;

    private int currentCameraIndex = 0;

    void Start()
    {
        if (cameras.Count == 0) return;

        // Enable only the first camera at start
        for (int i = 0; i < cameras.Count; i++)
        {
            cameras[i].gameObject.SetActive(i == 0);
        }

        StartCoroutine(SwitchCameras());
    }

    IEnumerator SwitchCameras()
    {
        while (currentCameraIndex < cameras.Count - 1)
        {
            yield return new WaitForSeconds(switchDelay);

            cameras[currentCameraIndex].gameObject.SetActive(false);
            currentCameraIndex++;
            cameras[currentCameraIndex].gameObject.SetActive(true);
        }

        // Wait again after last camera
        yield return new WaitForSeconds(switchDelay);

        // Load "win1" scene
        SceneManager.LoadScene("win1");
    }
}

