﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class alienfiremove : MonoBehaviour
{
    public float speed = 10f;
    private Transform player;
    private Rigidbody rb;
    public AudioClip hitSound; // 🎯 Sound to play on hit

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
        if (playerObj != null)
        {
            player = playerObj.transform;
        }
    }

    void FixedUpdate()
    {
        if (player != null)
        {
            Vector3 direction = (player.position - transform.position).normalized;
            rb.MovePosition(rb.position + direction * speed * Time.fixedDeltaTime);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("Hit Player!");

            // 🔊 Play hit sound at the collision point
            if (hitSound != null)
            {
                GameObject tempAudioObj = new GameObject("HitSound");
                tempAudioObj.transform.position = transform.position;

                AudioSource audioSource = tempAudioObj.AddComponent<AudioSource>();
                audioSource.clip = hitSound;
                audioSource.spatialBlend = 1f; // Make it 3D
                audioSource.Play();

                Destroy(tempAudioObj, hitSound.length); // Clean up after playback
            }

            // Reduce life
            Player_Management playerManager = collision.gameObject.GetComponent<Player_Management>();
            if (playerManager != null)
            {
                playerManager.ReduceLife(10f);
            }

            Destroy(gameObject); // Destroy projectile
        }
    }

}
