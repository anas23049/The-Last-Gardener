using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class buildingcollectibles : MonoBehaviour
{
    public GameObject[] collectiblePrefabs;  // Assign 3 different types in Inspector
    public int collectibleCount = 5;
    public float spawnRadius = 50f;
    public GameObject spawnAroundObject;     // Assign the building GameObject here

    void Start()
    {
        if (spawnAroundObject == null)
        {
            Debug.LogWarning("SpawnAroundObject not assigned!");
            return;
        }

        SpawnCollectibles();
    }

    void SpawnCollectibles()
    {
        if (collectiblePrefabs.Length == 0 || spawnAroundObject == null)
            return;

        Vector3 basePos = spawnAroundObject.transform.position;

        for (int i = 0; i < collectibleCount; i++)
        {
            int randomIndex = Random.Range(0, collectiblePrefabs.Length);

            Vector3 offset = new Vector3(
                Random.Range(-spawnRadius, spawnRadius),
                1f,
                Random.Range(-spawnRadius, spawnRadius)
            );

            Vector3 spawnPos = basePos + offset;

            Instantiate(collectiblePrefabs[randomIndex], spawnPos, Quaternion.identity);
        }
    }
}
